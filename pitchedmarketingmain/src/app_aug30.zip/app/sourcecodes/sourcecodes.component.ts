import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcecodes',
  templateUrl: './sourcecodes.component.html',
  styleUrls: ['./sourcecodes.component.css']
})
export class SourcecodesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
