import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcecodesdetail',
  templateUrl: './sourcecodesdetail.component.html',
  styleUrls: ['./sourcecodesdetail.component.css']
})
export class SourcecodesdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
