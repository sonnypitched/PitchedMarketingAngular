import { Component } from '@angular/core';
import { Template } from '@angular/compiler/src/render3/r3_ast';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

})
export class AppComponent {
  title = 'Pitched';
 
}



