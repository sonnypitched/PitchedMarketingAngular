export interface EmailTemplateModel {
  id: number;
  templateName: string;
  subject: string;
  createdBy: string;
}


