export interface CustomerSubscriptionModel {
  id: number;
  subscriptionname: string;
  title: string;
}


